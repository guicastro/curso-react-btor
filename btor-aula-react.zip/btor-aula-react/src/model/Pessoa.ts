interface Pessoa {
    nome: string,
    email: string,
    idade: number,
    id: number
}

export default Pessoa;